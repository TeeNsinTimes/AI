import math
import random
import numpy as np
from scipy.stats import beta
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

#arm = [0.3, 0.7, 0.8]
#reward = 20
#iters = 1000
arm = [0.1, 0.3, 0.5, 0.7, 0.9]
reward = 20
iters = 1000

def ϵ_greedy(ep):
    r = [0] * len(arm)
    cnt = [0] * len(arm)
    Q = [math.inf] * len(arm)

    for i in range(iters):
        best = Q.index(max(Q))
        pull = best
        if random.random() <= ep:
            pull = random.randint(0, len(arm) - 1)
        cnt[pull] += 1
        if random.random() <= arm[pull]:
            r[pull] += reward
        Q[pull] = r[pull] / cnt[pull]

    total = 0
    print("ϵ-Greedy:")
    for i in range(len(arm)):
        print("Pull arm " + str(i) + " " + str(cnt[i]) + " times, get " + str(r[i]))
        total += r[i]
    print("Total reward = " + str(total))
    '''
    plt.title("PDF (ϵ-Greedy)", fontsize=20)
    plt.ylabel("pdf", fontsize=16)
    x = np.linspace(0, 1, 10000)
    for i in range(len(arm)):
        y = beta.pdf(x, r[i]/reward, cnt[i]-r[i]/reward)
        plt.plot(x, y, linewidth=3, color=mcolors.TABLEAU_COLORS[list(mcolors.TABLEAU_COLORS)[i]], label="arm "+str(i))
    plt.legend(loc='upper right', shadow=True)
    plt.show()
    '''
    return total

#ϵ_greedy(0.1)
#ϵ_greedy(0.05)

def UCB(C):
    r = [0] * len(arm)
    cnt = [0] * len(arm)
    Q = [math.inf] * len(arm)
    A = [math.inf] * len(arm)

    for i in range(iters):
        pull = A.index(max(A))
        cnt[pull] += 1
        if random.random() <= arm[pull]:
            r[pull] += reward
        Q[pull] = r[pull] / cnt[pull]
        for j in range(len(arm)):
            if cnt[j] == 0:
                A[j] = math.inf
            else:
                A[j] = Q[j] + C * math.sqrt(np.log(i+1)/cnt[j])

    total = 0
    print("UCB:")
    for i in range(len(arm)):
        print("Pull arm " + str(i) + " " + str(cnt[i]) + " times, get " + str(r[i]))
        total += r[i]
    print("Total reward = " + str(total))
    '''
    plt.title("PDF (UCB)", fontsize=20)
    plt.ylabel("pdf", fontsize=16)
    x = np.linspace(0, 1, 10000)
    for i in range(len(arm)):
        y = beta.pdf(x, r[i] / reward, cnt[i] - r[i] / reward)
        plt.plot(x, y, linewidth=3, color=mcolors.TABLEAU_COLORS[list(mcolors.TABLEAU_COLORS)[i]], label="arm "+str(i))
    plt.legend(loc='upper right', shadow=True)
    plt.show()
    '''
    return total

#UCB(0.5)
#UCB(5)
#UCB(50)

def TS():
    cnt = [0] * len(arm)
    A = [1] * len(arm)
    B = [1] * len(arm)

    for i in range(iters):
        pull = -1
        argmax = -1
        for j in range(len(arm)):
            theta = np.random.beta(A[j], B[j])
            if argmax < theta:
                argmax = theta
                pull = j
        R = 0
        if random.random() <= arm[pull]:
            R = 1
        A[pull] += R
        B[pull] += (1 - R)
        cnt[pull] += 1

    total = 0
    print("TS:")
    for i in range(len(arm)):
        print("Pull arm " + str(i) + " " + str(cnt[i]) + " times, get " + str(A[i] * reward))
        total += A[i] * reward
    print("Total reward = " + str(total))
    '''
    plt.title("PDF (TS)", fontsize=20)
    plt.ylabel("pdf", fontsize=16)
    x = np.linspace(0, 1, 10000)
    for i in range(len(arm)):
        y = beta.pdf(x, A[i], cnt[i] - A[i])
        plt.plot(x, y, linewidth=3, color=mcolors.TABLEAU_COLORS[list(mcolors.TABLEAU_COLORS)[i]], label="arm "+str(i))
    plt.legend(loc='upper right', shadow=True)
    plt.show()
    '''
    return total

#TS()

def cmp(e, c):
    best_greedy = 0
    worst_greedy = reward * iters
    total_greedy = 0
    best_UCB = 0
    worst_UCB = reward * iters
    total_UCB = 0
    best_TS = 0
    worst_TS = reward * iters
    total_TS = 0
    for i in range(1000):
        ep = ϵ_greedy(e)
        best_greedy = max(best_greedy, ep)
        worst_greedy = min(worst_greedy, ep)
        total_greedy += ep
        U = UCB(c)
        best_UCB = max(best_UCB, U)
        worst_UCB = min(worst_UCB, U)
        total_UCB += U
        T = TS()
        best_TS = max(best_TS, T)
        worst_TS = min(worst_TS, T)
        total_TS += T
    print("Best ϵ_greedy = "+str(best_greedy)+", Worst ϵ_greedy = "+str(worst_greedy)+", Avg ϵ_greedy = "+str(total_greedy/1000))
    print("Best UCB = " + str(best_UCB) + ", Worst UCB = " + str(worst_UCB) + ", Avg UCB = " + str(total_UCB / 1000))
    print("Best TS = " + str(best_TS) + ", Worst TS = " + str(worst_TS) + ", Avg TS = " + str(total_TS / 1000))

cmp(0.1, 0.5)
#cmp(0.05, 10)

def test_ϵ():
    for i in range(10):
        best_greedy = 0
        worst_greedy = reward * iters
        total_greedy = 0
        e = 0.05 * (i+1)
        for j in range(100):
            ep = ϵ_greedy(e)
            best_greedy = max(best_greedy, ep)
            worst_greedy = min(worst_greedy, ep)
            total_greedy += ep
        print("Best ϵ_greedy = " + str(best_greedy) + ", Worst ϵ_greedy = " + str(worst_greedy) + ", Avg ϵ_greedy = " + str(total_greedy/100))

#test_ϵ()

def test_UCB():
    for i in range(100):
        best_UCB = 0
        worst_UCB = reward * iters
        total_UCB = 0
        c = 0.5*(i+1)
        for j in range(100):
            U = UCB(c)
            best_UCB = max(best_UCB, U)
            worst_UCB = min(worst_UCB, U)
            total_UCB += U
        print("Best UCB = " + str(best_UCB) + ", Worst UCB = " + str(worst_UCB) + ", Avg UCB = " + str(total_UCB/100))

#test_UCB()

import queue
from collections import deque
import heapq

N = 16;  # Number of Cities
NOPATH = 14400  # 10 Days

Cities = {"Kaohsiung": 0, "Nantou": 1, "Keelung": 2, "Taipei": 3, "Taoyuan": 4, "Hsinchu": 5,
          "Miaoli": 6, "Taichung": 7, "Changhua": 8, "Yunling": 9, "Chiayi": 10, "Tainan": 11,
          "Pingtung": 12, "Taitung": 13, "Hualian": 14, "Ilan": 15}  # All Cities
CitiesR = {0: "Kaohsiung", 1: "Nantou", 2: "Keelung", 3: "Taipei", 4: "Taoyuan", 5: "Hsinchu",
           6: "Miaoli", 7: "Taichung", 8: "Changhua", 9: "Yunling", 10: "Chiayi", 11: "Tainan",
           12: "Pingtung", 13: "Taitung", 14: "Hualian", 15: "Ilan"}  # Index to City

C = [[0] * N for i in range(N)]  # Costs
H = [[0] * N for i in range(N)]  # Heuristic Function
for i in range(N):
    for j in range(N):
        C[i][j] = NOPATH;
        H[i][j] = NOPATH;
# Kaohsiung -> Tainan(0, 11)
C[0][11] = 68
H[0][11] = 45
# Kaohsiung -> Pingtung(0, 12)
C[0][12] = 45
H[0][12] = 33
# Kaohsiung -> Taitung(0, 13)
C[0][13] = 190
H[0][13] = 165

# Nantou -> Taichung(1, 7)
C[1][7] = 70
H[1][7] = 55
# Nantou -> Changhua(1, 8)
C[1][8] = 55
H[1][8] = 50
# Nantou -> Hualian(1, 14)
C[1][14] = 270
H[1][14] = 265

# Keelung -> Taipei(2, 3)
C[2][3] = 37
H[2][3] = 24
# Keelung -> Ilan(2, 15)
C[2][15] = 70
H[2][15] = 60

# Taipei -> Keelung(3, 2)
C[3][2] = 36
H[3][2] = 23
# Taipei -> Taoyuan(3, 4)
C[3][4] = 83
H[3][4] = 43
# Taipei -> Ilan(3, 15)
C[3][15] = 68
H[3][15] = 55

# Taoyuan -> Taipei(4, 3)
C[4][3] = 70
H[4][3] = 38
# Taoyuan -> Hsinchu(4, 5)
C[4][5] = 70
H[4][5] = 45
# Taoyuan -> Ilan(4, 15)
C[4][15] = 115
H[4][15] = 83

# Hsinchu -> Taoyuan(5, 4)
C[5][4] = 68
H[5][4] = 38
# Hsinchu -> Miaoli(5, 6)
C[5][6] = 50
H[5][6] = 40

# Miaoli -> Hsinchu(6, 5)
C[6][5] = 70
H[6][5] = 43
# Miaoli -> Taichung(6, 7)
C[6][7] = 75
H[6][7] = 53

# Taichung -> Nantou(7, 1)
C[7][1] = 65
H[7][1] = 53
# Taichung -> Miaoli(7, 6)
C[7][6] = 75
H[7][6] = 53
# Taichung -> Changhua(7, 8)
C[7][8] = 50
H[7][8] = 30

# Changhua -> Nantou(8, 1)
C[8][1] = 60
H[8][1] = 55
# Changhua -> Taichung(8, 7)
C[8][7] = 48
H[8][7] = 33
# Changhua -> Yunling(8, 9)
C[8][9] = 48
H[8][9] = 40

# Yunling -> Changhua(9, 8)
C[9][8] = 48
H[9][8] = 43
# Yunling -> Chiayi(9, 10)
C[9][10] = 50
H[9][10] = 40

# Chiayi -> Yunling(10, 9)
C[10][9] = 45
H[10][9] = 40
# Chiayi -> Tainan(10, 11)
C[10][11] = 63
H[10][11] = 53

# Tainan -> Kaohsiung(11, 0)
C[11][0] = 63
H[11][0] = 40
# Tainan -> Chiayi(11, 10)
C[11][10] = 58
H[11][10] = 53

# Pingtung -> Kaohsiung(12, 0)
C[12][0] = 45
H[12][0] = 28
# Pingtung -> Taitung(12, 13)
C[12][13] = 160
H[12][13] = 145

# Taitung -> Kaohsiung(13, 0)
C[13][0] = 190
H[13][0] = 160
# Taitung -> Pingtung(13, 12)
C[13][12] = 165
H[13][12] = 145
# Taitung -> Hualien(13, 14)
C[13][14] = 195
H[13][14] = 170

# Hualien -> Nantou(14, 1)
C[14][1] = 275
H[14][1] = 265
# Hualien -> Taitung(14, 13)
C[14][13] = 205
H[14][13] = 190
# Hualien -> Ilan(14, 15)
C[14][15] = 150
H[14][15] = 125

# Ilan -> Keelung(15, 2)
C[15][2] = 83
H[15][2] = 60
# Ilan -> Taipei(15, 3)
C[15][3] = 83
H[15][3] = 55
# Ilan -> Taoyuan(15, 4)
C[15][4] = 125
H[15][4] = 90
# Ilan -> Hualien(15, 14)
C[15][14] = 140
H[15][14] = 125

def UCSH(ff, tt):
    pq = queue.PriorityQueue()
    pq.put((0, [ff]))

    while not pq.empty():
        node = pq.get()
        cur = node[1][len(node[1]) - 1]

        if cur == tt:
            return node[0]
            break

        cost = node[0]
        for i in range(N):
            if H[cur][i] != NOPATH:
                tmp = node[1][:]
                tmp.append(i)
                pq.put((cost + H[cur][i], tmp))

heuri = [[0] * N for i in range(N)]
for i in range(N):
    for j in range(2):
        heuri[i][j] = UCSH(i, j)

fr = -1
to = -1

def BFS():
    print("BFS: ", end='')
    parent = [0] * N
    for i in range(N):
        parent[i] = -2

    q = queue.Queue()  # FIFO
    q.put(fr)
    parent[fr] = -1

    while not q.empty():
        cur = q.get()
        if cur == to:
            break
        for i in range(N):
            if C[cur][i] != NOPATH and parent[i] == -2:
                q.put(i)
                parent[i] = cur

    tmp = to
    seq = queue.LifoQueue()  # FILO
    while not parent[tmp] == -1:
        seq.put(tmp)
        tmp = parent[tmp]

    print(CitiesR[fr], end='')
    cost = 0
    tfr = fr
    while not seq.empty():
        tto = seq.get()
        print(" -> " + CitiesR[tto], end='')
        cost += C[tfr][tto]
        tfr = tto

    print(", Cost =", cost)


def DFS():
    print("DFS: ", end='')
    parent = [0] * N
    for i in range(N):
        parent[i] = -2

    nxt = deque()
    nxt.appendleft(fr)
    parent[fr] = -1

    while nxt:
        cur = nxt.popleft()
        if cur == to:
            break
        for i in range(N):
            if C[cur][i] != NOPATH and parent[i] == -2:
                parent[i] = cur
                nxt.appendleft(i)

    tmp = to
    seq = queue.LifoQueue()  # FILO
    while not parent[tmp] == -1:
        seq.put(tmp)
        tmp = parent[tmp]

    print(CitiesR[fr], end='')
    cost = 0
    tfr = fr
    while not seq.empty():
        tto = seq.get()
        print(" -> " + CitiesR[tto], end='')
        cost += C[tfr][tto]
        tfr = tto

    print(", Cost =", cost)

def IDDFS():
    print("IDDFS: ", end='')

    for depth in range(N):
        parent = [0] * N
        for i in range(N):
            parent[i] = -2

        nxt = deque()
        nxt.appendleft((fr, 0)) #(node, depth)
        parent[fr] = -1

        found = False;

        while nxt:
            cur = nxt.popleft()
            if cur[0] == to:
                found = True
                break
            for i in range(N):
                if C[cur[0]][i] != NOPATH and parent[i] == -2 and cur[1] + 1 <= depth:
                    parent[i] = cur[0]
                    nxt.appendleft((i, cur[1] + 1))

        if found:
            tmp = to
            seq = queue.LifoQueue()  # FILO
            while not parent[tmp] == -1:
                seq.put(tmp)
                tmp = parent[tmp]

            print(CitiesR[fr], end='')
            cost = 0
            tfr = fr
            while not seq.empty():
                tto = seq.get()
                print(" -> " + CitiesR[tto], end='')
                cost += C[tfr][tto]
                tfr = tto

            print(", Cost =", cost)
            break

def UCS():
    print("UCS: ", end='')

    pq = queue.PriorityQueue()
    pq.put((0, [fr]))

    while not pq.empty():
        node = pq.get()
        cur = node[1][len(node[1]) - 1] #current point

        if cur == to:
            for i in range(len(node[1])):
                print(CitiesR[node[1][i]], end='')
                if i < len(node[1]) - 1:
                    print(" -> ", end='')
            print(", Cost =", node[0])
            break

        cost = node[0]
        for i in range(N):
            if C[cur][i] != NOPATH:
                tmp = node[1][:]
                tmp.append(i)
                pq.put((cost + C[cur][i], tmp))

def AStar():
    print("A*: ", end='')

    pq = queue.PriorityQueue()
    pq.put((0, 0, [fr]))

    vis = [0] * N
    for i in range(N):
        if C[i][to] == NOPATH:
            vis[i] = True
        else:
            vis[i] = False

    min_path = (NOPATH, [])

    while not pq.empty():
        node = pq.get()
        cur = node[2][len(node[2]) - 1]

        if cur == to:
            min_path = min(min_path, (node[1], node[2]))
            if len(node[2]) > 1:
                vis[node[2][len(node[2]) - 2]] = True
            expanded = True
            for i in range(N):
                if vis[i] != True:
                    expanded = False
                    break
            if expanded:
                break

        cost = node[1]
        for i in range(N):
            if C[cur][i] != NOPATH:
                tmp = node[2][:]
                tmp.append(i)
                pq.put((cost + heuri[i][to], cost + C[cur][i], tmp))

    for i in range(len(min_path[1])):
        print(CitiesR[min_path[1][i]], end='')
        if i < len(min_path[1]) - 1:
            print(" -> ", end='')
    print(", Cost =", min_path[0], "\n")

for i in range(N):
    for j in range(2):
        print("From", CitiesR[i], "to", CitiesR[j], '-')
        fr = i
        to = j
        BFS()
        DFS()
        IDDFS()
        UCS()
        AStar()

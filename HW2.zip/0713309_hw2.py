import csv
import random
import matplotlib.pyplot as plt
import numpy as np
import math

N = 500
Train_Size = 400
Test_Size = 100


def read_data(file_path, var_name, mean_sigma):
    with open(file_path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        i = 0
        for row in csv_reader:
            var_name[i] = float(row[0])
            i += 1

    # Normalize---------------------------------------------------------------------------
    sx = 0.0
    sxx = 0.0
    for i in range(N):
        sx += var_name[i]
        sxx += var_name[i] * var_name[i]

    mean_sigma[0] = sx / N
    mean_sigma[1] = ((N * sxx - sx * sx) / (N * (N - 1))) ** 0.5

    for i in range(N):
        var_name[i] = (var_name[i] - mean_sigma[0]) / mean_sigma[1]

def read_data2(file_path, var_name, mean_sigma):
    with open(file_path) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        i = 0
        for row in csv_reader:
            if float(row[0]) == 0.0:
                var_name[i] = -1
            else:
                var_name[i] = float(row[0])
            i += 1

    # Normalize---------------------------------------------------------------------------
    sx = 0.0
    sxx = 0.0
    for i in range(N):
        sx += var_name[i]
        sxx += var_name[i] * var_name[i]

    mean_sigma[0] = sx / N
    mean_sigma[1] = ((N * sxx - sx * sx) / (N * (N - 1))) ** 0.5

    for i in range(N):
        var_name[i] = (var_name[i] - mean_sigma[0]) / mean_sigma[1]

def P1(iter, rate, norm):
    iterations = iter
    learning_rate = rate

    # Read Data---------------------------------------------------------------------------
    X = [0] * N
    Y = [0] * N
    mean_sigmaX = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 1\Averaged homework scores.csv', X, mean_sigmaX)
    read_data('dataset\Problem 1\Final exam scores.csv', Y, mean_sigmaY)

    # Initialize weight & bias------------------------------------------------------------
    w = random.uniform(0.0, 1.0)
    b = 0.0

    # Iteration---------------------------------------------------------------------------
    for i in range(iterations):
        idx = random.randint(1, Train_Size) - 1
        x = X[idx]
        y = Y[idx]
        dif = w * x + b - y
        # print(f"i = {i} {w} {b}")
        b -= learning_rate * (2 * dif)
        w -= learning_rate * (2 * x * dif)

    # print(w)
    # print(b)

    # Plot--------------------------------------------------------------------------------
    show_normalized = norm  # control whether show normalized data or not

    if show_normalized == 0:
        x = np.linspace(50, 100, 2)
        # y = (w * (x - mean_sigmaX[0]) / mean_sigmaX[1] + b) * mean_sigmaY[1] + mean_sigmaY[0]
        #   = (w / mean_sigmaX[1] * mean_sigmaY[1]) * x + ((b - w * mean_sigmaX[0] / mean_sigmaX[1]) * mean_sigmaY[1] + mean_sigmaY[0])
        b = (b - w * mean_sigmaX[0] / mean_sigmaX[1]) * mean_sigmaY[1] + mean_sigmaY[0]
        w = w / mean_sigmaX[1] * mean_sigmaY[1]
    else:
        x = np.linspace(-3, 3, 2)

    y = w * x + b

    plt.plot(x, y, label='Linear Regression')
    plt.title('Linear Regression', fontsize='xx-large', fontweight='heavy')
    plt.xlabel('Averaged homework scores')
    plt.ylabel('Final exam scores')

    MSE = 0
    for i in range(Test_Size):
        if i == 0:
            if show_normalized == 0:
                MSE += ((w * (X[400 + i] * mean_sigmaX[1] + mean_sigmaX[0]) + b) - (
                            Y[400 + i] * mean_sigmaY[1] + mean_sigmaY[0])) ** 2
                plt.plot(X[400 + i] * mean_sigmaX[1] + mean_sigmaX[0], Y[400 + i] * mean_sigmaY[1] + mean_sigmaY[0],
                         'ro', label='Testing Data')
            else:
                MSE += ((w * X[400 + i] + b) - Y[400 + i]) ** 2
                plt.plot(X[400 + i], Y[400 + i], 'ro', label='Testing Data')
        else:
            if show_normalized == 0:
                MSE += ((w * (X[400 + i] * mean_sigmaX[1] + mean_sigmaX[0]) + b) - (
                            Y[400 + i] * mean_sigmaY[1] + mean_sigmaY[0])) ** 2
                plt.plot(X[400 + i] * mean_sigmaX[1] + mean_sigmaX[0], Y[400 + i] * mean_sigmaY[1] + mean_sigmaY[0],
                         'ro')
            else:
                MSE += ((w * X[400 + i] + b) - Y[400 + i]) ** 2
                plt.plot(X[400 + i], Y[400 + i], 'ro')

    MSE /= Test_Size
    print(f'MSE of P1 = {MSE}')

    plt.legend()
    plt.show()

def P2(iter, rate, norm):
    iterations = iter
    learning_rate = rate

    # Read Data---------------------------------------------------------------------------
    X1 = [0] * N
    X2 = [0] * N
    Y = [0] * N
    mean_sigmaX1 = [0] * 2
    mean_sigmaX2 = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 2\Averaged homework scores.csv', X1, mean_sigmaX1)
    read_data('dataset\Problem 2\Final exam scores.csv', X2, mean_sigmaX2)
    read_data2('dataset\Problem 2\Results.csv', Y, mean_sigmaY)

    # Initialize weights & bias------------------------------------------------------------
    w1 = random.uniform(0.0, 0.5)
    w2 = random.uniform(0.0, 0.5)
    b = 0.0

    # Iteration---------------------------------------------------------------------------
    for i in range(iterations):
        idx = random.randint(1, Train_Size) - 1
        x1 = X1[idx]
        x2 = X2[idx]
        y = Y[idx]
        tmpexp = math.exp(-y * (w1 * x1 + w2 * x2 + b))
        # print(f"i = {i} {w1} {w2} {b}")
        b -= learning_rate * (- tmpexp * y / (1 + tmpexp))
        w1 -= learning_rate * (- tmpexp * y * x1 / (1 + tmpexp))
        w2 -= learning_rate * (- tmpexp * y * x2 / (1 + tmpexp))

    # Plot--------------------------------------------------------------------------------
    show_normalized = norm  # control whether show normalized data or not

    if show_normalized == 0:
        x1 = np.linspace(50, 100, 2)
        # y = (w1 * (x1 - mean_sigmaX1[0]) / mean_sigmaX1[1] + w2 * (x2 - mean_sigmaX2[0]) / mean_sigmaX2[1] + b) * mean_sigmaY[1] + mean_sigmaY[0]
        #   = (w1 / mean_sigmaX1[1] * mean_sigmaY[1]) * x1 + (w2 / mean_sigmaX2[1] * mean_sigmaY[1]) * x2 + ((b - w1 * mean_sigmaX1[0] / mean_sigmaX1[1] - w2 * mean_sigmaX2[0] / mean_sigmaX2[1]) * mean_sigmaY[1] + mean_sigmaY[0])
        b = (b - w1 * mean_sigmaX1[0] / mean_sigmaX1[1] - w2 * mean_sigmaX2[0] / mean_sigmaX2[1]) * mean_sigmaY[1] + \
            mean_sigmaY[0]
        w1 = w1 / mean_sigmaX1[1] * mean_sigmaY[1]
        w2 = w2 / mean_sigmaX2[1] * mean_sigmaY[1]
    else:
        x1 = np.linspace(-3, 3, 2)

    # print(f'{w1} {w2} {b}')

    # y = w1 * x1 + w2 * x2 + b
    x2 = (0.5 - b - w1 * x1) / w2

    plt.plot(x1, x2, label='Decision Boundary', color='black')
    plt.title('Logistic Regression', fontsize='xx-large', fontweight='heavy')
    plt.xlabel('Averaged homework scores')
    plt.ylabel('Final exam scores')

    firstaccept = True
    firstreject = True
    Loss = 0

    for i in range(Test_Size):
        if show_normalized == 0:
            X1[400 + i] = X1[400 + i] * mean_sigmaX1[1] + mean_sigmaX1[0]
            X2[400 + i] = X2[400 + i] * mean_sigmaX2[1] + mean_sigmaX2[0]

        Loss += math.log(1 + math.exp(-Y[400 + i] * (w1 * X1[400 + i] + w2 * X2[400 + i] + b)))

        if Y[400 + i] > mean_sigmaY[0]:
            if firstaccept:
                plt.plot(X1[400 + i], X2[400 + i], 'ro', label='Accepted', color='blue')
                firstaccept = False
            else:
                plt.plot(X1[400 + i], X2[400 + i], 'ro', color='blue')
        else:
            if firstreject:
                plt.plot(X1[400 + i], X2[400 + i], 'ro', label='Rejected', color='red')
                firstreject = False
            else:
                plt.plot(X1[400 + i], X2[400 + i], 'ro', color='red')

    Loss /= Test_Size
    print(f'Mean loss of P2 = {Loss}')

    plt.legend()
    plt.show()

P1(1000, 0.01, 0)
P2(1000, 0.75, 1)

def P1_with_out_Normalization():
    # iterations = 1000
    learning_rate = 0.01

    # Read Data---------------------------------------------------------------------------
    X = [0] * N
    Y = [0] * N
    with open('dataset\Problem 1\Averaged homework scores.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        i = 0
        for row in csv_reader:
            X[i] = float(row[0])
            i += 1
    with open('dataset\Problem 1\Final exam scores.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        i = 0
        for row in csv_reader:
            Y[i] = float(row[0])
            i += 1

    # plt.title('Linear Regression without Normalization, fixed iterations(= 1000)', fontsize=12, fontweight='heavy')
    plt.title('Linear Regression without Normalization, fixed learning rate(= 0.01)', fontsize=12, fontweight='heavy')
    plt.xlabel('Iterations')
    plt.ylabel('MSE')
    plt.yscale('log')

    iterations = 0
    while iterations < 1000:
        iterations += 1
    # learning_rate = 0.0000000
    # while learning_rate < 0.00001:
        # learning_rate += 0.000000005

        # Initialize weight & bias--------------------------------------------------------
        w = random.uniform(0.0, 1.0)
        b = 0.0
        print(iterations)
        # Iteration---------------------------------------------------------------------------
        toolarge = False
        for i in range(iterations):
            idx = random.randint(1, Train_Size) - 1
            x = X[idx]
            y = Y[idx]
            dif = w * x + b - y
            if w > 1e100:
                toolarge = True
                break
            # print(f"i = {i} {w} {b}")
            b -= learning_rate * (2 * dif)
            w -= learning_rate * (2 * x * dif)

        if toolarge:
            continue

        MSE = 0
        for i in range(Test_Size):
            MSE += ((w * X[400 + i] + b) - Y[400 + i]) ** 2

        MSE /= Test_Size

        if MSE < 1e100:
            plt.plot(iterations, MSE, 'ro')

    plt.legend()
    plt.show()

#P1_with_out_Normalization()

def P1_adjust_iter_and_lr():
    iterations = 1000
    #learning_rate = 0.01

    # Read Data---------------------------------------------------------------------------
    X = [0] * N
    Y = [0] * N
    mean_sigmaX = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 1\Averaged homework scores.csv', X, mean_sigmaX)
    read_data('dataset\Problem 1\Final exam scores.csv', Y, mean_sigmaY)

    #iterations = 0
    #while(iterations < 1e3):
        #iterations += 1
    learning_rate = 0.0
    while (learning_rate < 0.1):
        learning_rate += 0.0001
        # Initialize weight & bias------------------------------------------------------------
        w = random.uniform(0.0, 1.0)
        b = 0.0
        # Iteration---------------------------------------------------------------------------
        for i in range(iterations):
            idx = random.randint(1, Train_Size) - 1
            x = X[idx]
            y = Y[idx]
            dif = w * x + b - y
            b -= learning_rate * (2 * dif)
            w -= learning_rate * (2 * x * dif)

        # Plot--------------------------------------------------------------------------------
        plt.title('Linear Regression (iterations = 1000, mini-batch size = 1)', fontsize='medium', fontweight='heavy')
        #plt.xlabel('Iterations')
        plt.xlabel('learning rate')
        plt.ylabel('MSE')

        MSE = 0
        for i in range(Test_Size):
            MSE += ((w * X[400 + i] + b) - Y[400 + i]) ** 2

        MSE /= Test_Size
        plt.plot(learning_rate, MSE, 'ro')

    plt.legend()
    plt.show()

#P1_adjust_iter_and_lr()

def P1_adjust_batch():
    iterations = 1000
    learning_rate = 0.01

    # Read Data---------------------------------------------------------------------------
    X = [0] * N
    Y = [0] * N
    mean_sigmaX = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 1\Averaged homework scores.csv', X, mean_sigmaX)
    read_data('dataset\Problem 1\Final exam scores.csv', Y, mean_sigmaY)

    batch_size = [1, 2, 4, 5, 8, 10]
    color = ['b', 'g', 'r', 'c', 'm', 'y']
    for i in range(6):
        # Initialize weight & bias------------------------------------------------------------
        w = random.uniform(0.0, 1.0)
        b = 0.0
        # Iteration---------------------------------------------------------------------------
        for j in range(math.floor(iterations / batch_size[i])):
            dif = 0
            x_mean = 0
            y_mean = 0
            for k in range(batch_size[i]):
                idx = random.randint(1, Train_Size) - 1
                x_mean += X[idx]
                y_mean += Y[idx]
            x_mean /= batch_size[i]
            y_mean /= batch_size[i]
            dif += w * x_mean + b - y_mean
            b -= learning_rate * (2 * dif)
            w -= learning_rate * (2 * x_mean * dif)

            MSE = 0
            for k in range(Test_Size):
                MSE += ((w * X[400 + k] + b) - Y[400 + k]) ** 2

            MSE /= Test_Size
            if j == 0:
                plt.plot((j + 1) * batch_size[i], MSE, 'ro', color=color[i], label=f'batch size = {batch_size[i]}')
            else:
                plt.plot((j + 1) * batch_size[i], MSE, 'ro', color=color[i])

        # Plot--------------------------------------------------------------------------------
        plt.title('Linear Regression (Sample Times = 1000, learning rate = 0.01)', fontsize='medium', fontweight='heavy')
        plt.xlabel('Data Seen')
        plt.ylabel('MSE')

    plt.legend()
    plt.show()

# P1_adjust_batch()

def P2_adjust_iter_and_lr():
    iterations = 1000

    # Read Data---------------------------------------------------------------------------
    X1 = [0] * N
    X2 = [0] * N
    Y = [0] * N
    mean_sigmaX1 = [0] * 2
    mean_sigmaX2 = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 2\Averaged homework scores.csv', X1, mean_sigmaX1)
    read_data('dataset\Problem 2\Final exam scores.csv', X2, mean_sigmaX2)
    read_data2('dataset\Problem 2\Results.csv', Y, mean_sigmaY)

    plt.title('Logistic Regression (Iterations = 1000, mini-batch size = 1)', fontsize='medium',
              fontweight='heavy')
    plt.xlabel('Learning Rate')
    plt.ylabel('Mean Logistic Loss')

    learning_rate = 0.0
    while learning_rate < 0.75:
        learning_rate += 0.001
        # Initialize weights & bias------------------------------------------------------------
        w1 = random.uniform(0.0, 0.5)
        w2 = random.uniform(0.0, 0.5)
        b = 0.0

        # Iteration---------------------------------------------------------------------------
        for i in range(iterations):
            idx = random.randint(1, Train_Size) - 1
            x1 = X1[idx]
            x2 = X2[idx]
            y = Y[idx]
            tmpexp = math.exp(-y * (w1 * x1 + w2 * x2 + b))
            # print(f"i = {i} {w1} {w2} {b}")
            b -= learning_rate * (- tmpexp * y / (1 + tmpexp))
            w1 -= learning_rate * (- tmpexp * y * x1 / (1 + tmpexp))
            w2 -= learning_rate * (- tmpexp * y * x2 / (1 + tmpexp))

        Loss = 0

        for i in range(Test_Size):
            Loss += math.log(1 + math.exp(-Y[400 + i] * (w1 * X1[400 + i] + w2 * X2[400 + i] + b)))

        Loss /= Test_Size
        plt.plot(learning_rate, Loss, 'ro')

    plt.legend()
    plt.show()

# P2_adjust_iter_and_lr()

def P2_adjust_batch():
    iterations = 1000
    learning_rate = 0.3

    # Read Data---------------------------------------------------------------------------
    X1 = [0] * N
    X2 = [0] * N
    Y = [0] * N
    mean_sigmaX1 = [0] * 2
    mean_sigmaX2 = [0] * 2
    mean_sigmaY = [0] * 2
    read_data('dataset\Problem 2\Averaged homework scores.csv', X1, mean_sigmaX1)
    read_data('dataset\Problem 2\Final exam scores.csv', X2, mean_sigmaX2)
    read_data2('dataset\Problem 2\Results.csv', Y, mean_sigmaY)

    plt.title('Logistic Regression (Sample Times = 1000, Learning Rate = 0.3)', fontsize='medium',
              fontweight='heavy')
    plt.xlabel('Data Seen')
    plt.ylabel('Mean Logistic Loss')

    batch_size = [1, 2, 4, 5, 8, 10]
    color = ['b', 'g', 'r', 'c', 'm', 'y']

    # Iteration---------------------------------------------------------------------------
    for i in range(6):
        # Initialize weights & bias------------------------------------------------------------
        w1 = random.uniform(0.0, 0.5)
        w2 = random.uniform(0.0, 0.5)
        b = 0.0
        for j in range(math.floor(iterations / batch_size[i])):
            idx = random.randint(1, Train_Size) - 1
            x1 = X1[idx]
            x2 = X2[idx]
            y = Y[idx]
            tmpexp = math.exp(-y * (w1 * x1 + w2 * x2 + b))
            # print(f"i = {i} {w1} {w2} {b}")
            b -= learning_rate * (- tmpexp * y / (1 + tmpexp))
            w1 -= learning_rate * (- tmpexp * y * x1 / (1 + tmpexp))
            w2 -= learning_rate * (- tmpexp * y * x2 / (1 + tmpexp))

            Loss = 0
            for k in range(Test_Size):
                Loss += math.log(1 + math.exp(-Y[400 + i] * (w1 * X1[400 + i] + w2 * X2[400 + i] + b)))

            if j == 0:
                plt.plot((j + 1) * batch_size[i], Loss, 'ro', color=color[i], label=f'batch size = {batch_size[i]}')
            else:
                plt.plot((j + 1) * batch_size[i], Loss, 'ro', color=color[i])

            Loss /= Test_Size
            plt.plot(learning_rate, Loss, 'ro')

    plt.legend()
    plt.show()

# P2_adjust_batch()
import os
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from keras.models import Sequential, load_model
from keras.datasets import cifar10
from keras.utils import np_utils, plot_model
from keras.layers import Dense, Dropout, Flatten, Conv2D, MaxPool2D

# Import the CIFAR-10 dataset
(train_image, train_label), (test_image, test_label) = cifar10.load_data()

# Part 1: A Simple Neural Network Implementation
def p1():
    train_im1 = train_image.reshape(50000, 3072).astype('float32') / 255
    test_im1 = test_image.reshape(10000, 3072).astype('float32') / 255
    train_la1 = np_utils.to_categorical(train_label)
    test_la1 = np_utils.to_categorical(test_label)

    model = Sequential()
    model.add(Dense(units=256, input_dim=3072, kernel_initializer='normal', activation='relu'))
    model.add(Dense(units=256, input_dim=3072, kernel_initializer='normal', activation='relu'))
    model.add(Dense(units=256, input_dim=3072, kernel_initializer='normal', activation='relu'))
    model.add(Dense(units=10, kernel_initializer='normal', activation='softmax'))

    print(model.summary())

    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

    model.fit(train_im1, train_la1, epochs=50, batch_size=1024, verbose=1)
    loss, accuracy = model.evaluate(test_im1, test_la1)
    print('Test:')
    print('Loss:', loss)
    print('Accuracy:', accuracy)

# Part 2:  Convolutional Neural Network (CNN) Implementation
def p2():
    train_im2 = train_image.astype('float32') / 255
    test_im2 = test_image.astype('float32') / 255
    train_la2 = np_utils.to_categorical(train_label)
    test_la2 = np_utils.to_categorical(test_label)

    model = Sequential()
    model.add(Conv2D(filters=64, kernel_size=3, input_shape=(32, 32, 3), activation='relu', padding='same'))
    model.add(Conv2D(filters=64, kernel_size=3, input_shape=(32, 32, 3), activation='relu', padding='same'))
    model.add(MaxPool2D(pool_size=2))

    model.add(Conv2D(filters=128, kernel_size=3, activation='relu', padding='same'))
    model.add(Conv2D(filters=128, kernel_size=3, activation='relu', padding='same'))
    model.add(MaxPool2D(pool_size=2))

    model.add(Conv2D(filters=128, kernel_size=3, activation='relu', padding='same'))
    model.add(Conv2D(filters=128, kernel_size=3, activation='relu', padding='same'))
    model.add(MaxPool2D(pool_size=2))

    model.add(Flatten())
    model.add(Dense(512, activation='relu'))
    model.add(Dropout(rate=0.25))
    model.add(Dense(10, activation='softmax'))

    print(model.summary())

    model.compile(loss='categorical_crossentropy', optimizer='Adam', metrics=['accuracy'])
    model.fit(train_im2, train_la2, epochs=10, batch_size=64, verbose=1)

    loss, accuracy = model.evaluate(test_im2, test_la2)
    print('Test:')
    print('Loss:', loss)
    print('Accuracy:', accuracy)

p2()